# HTML Boilerplate 

En boilerplate er brugt til at komme godt fra start! Og det er så blevet til et online magasin!
